import java.util.Random;

public class Main {
    public static void main(String[] args) {
      /*  //Основной поток
        MyThreads1 myThreads1 = new MyThreads1();

        //Поток setDaemon - приложение завершится в main, когда исполниться while
        myThreads1.setDaemon(true);

        //Определение приоритета потока - ограничение
        myThreads1.setPriority(Thread.MIN_PRIORITY);
        myThreads1.start();
        int laps = 10000;
        while (laps > 0){
            System.out.println(".");
            laps--;
        }
    }
}
//Дополнительный поток и переопределенный метод run
class MyThreads1 extends Thread{
    @Override
    public void run() {
      while (true){
          System.out.println("A");}*/

        int v = (new Random().nextInt(10));
        MyThreads2 myThreads2 = new MyThreads2(v);
      myThreads2.setDaemon(true);
        v = (new Random().nextInt(10));
        MyThreads2 myThreads21 = new MyThreads2(v);
        myThreads21.setDaemon(true);
        myThreads21.start();
        myThreads2.start();

        //задержка основного потока на 5000 милисекунд
        try{
      //      Thread.sleep(5000);

            //join приостанавливает основной поток от того потока, которыым он вызван
            myThreads21.join(1000);
            myThreads2.join(1000);
        }
        catch (InterruptedException e){
        }

// поток будет работать пока поток будет исполняется поток
  /*      while (myThreads21.isAlive() || myThreads2.isAlive()){
        }*/


        //потоки с выводом имени и возраста
       //Имя
        /*MyThreadsName myThreadsName = new myThreadsName();
        MyThreadsName.setDaemon(true);
        MyThreadsName.start();
        int laps = 10000;
        while (laps > 0){
            System.out.println("Dimitry");
            laps--;*/
        }



      }
    }


        //2й пример

class  MyThreads2 extends Thread{
    private  int value;
    public  MyThreads2 (int value){
        this.value = value;
    }
    public void run() {
        while (this.value >= 0){
            System.out.println("********* The Threads" + Thread.currentThread().getName() + "started with" + this.value);
            while (this.value >= 0){
                System.out.println("********* From" + Thread.currentThread().getName() + "started with" + this.value);
                this.value -= 1;
                try {
                    Thread.sleep(300); //Задержка потока в милисекундах
                }
                catch (InterruptedException e){
                }
        }
        }
        System.out.println("******* The Thread " + Thread.currentThread().getName() + "has finish");
    }
}