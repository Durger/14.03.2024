import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
// Задача1. Пользователь вводит с клавиатуры в строку набор символов от 0-9. Необходимо преобразовать строку в число целого типа.
//Предусмотреть случай выхода за границы диапазона, определяемого типом int. Используйте механизм исключений.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите числа от 1 до 9: ");
        String input = scanner.nextLine();
        try{
            int number = Integer.parseInt(input);
        }
        catch(NumberFormatException e){
            System.out.println("Ошибка ввода: Ввведенная строка не является числом или Вы вышли за пределы диапазона чисел!!!" + e);
        }
        finally{
        }
//Задание 2. Пользователь вводит с клавиатуры в строку набор 0 и 1. Необходимо преобразовать строку в число целого
// типа в десятичном представлении. Предусмотреть случай выхода за границы диапазона, определяемого типом int,
//неправильный ввод. Используйте механизм исключений.

        System.out.println("?????????????????");
        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Введите строку из набора 0 и 1: ");
        String input1 = scanner.nextLine();
        try{
            int number2 = Integer.parseInt(input);
            System.out.println("Преобразованное число: " + number2);
        }
        catch(NumberFormatException e){
            System.out.println("Ошибка преобразования: Ввведенная строка не является двоичным числом или выходит за границы диапазона!!!" + e);
        }
        finally{
        }
//Задание.4. Пользователь вводит в строку с клавиатуры математическое выражение. Например, 3+8+10+11. Программа
//должна посчитать результат введенного выражения. В строке могут быть только целые числа и оператор +(в унарном
// или бинарном виде). Для обработки ошибок ввода используйте механизм исключений.

        System.out.println("%%%%%%%%%%%%%%%%%%%%");
        Scanner scanner4 = new Scanner(System.in);
        System.out.println("Введите математическое выражение");
        String input4 = scanner.nextLine();
        try{
            int result3 = evaluteException(input4);
            System.out.println("Результат: " + result3);
        }
        catch(Exception e){
            System.out.println("Ошибка: " + e.getMessage());
        }
    }
    public static int evaluteException(String expressions) throws Exception{
        int result = 0;
        int currectNumber = 0;
        char operator = '+';
            for(int i = 0; i < expressions.length(); i++ ){
                char ch = expressions.charAt(i);
            if(Character.isDigit(ch)){
                currectNumber = currectNumber * 10 + (ch-'0');
            }
            if(!Character.isDigit(ch) && ch!=' ' || i == expressions.length() - 1){
                if(operator == '+'){
                    result += currectNumber;
                }
                else if(operator == '-'){
                    result -= currectNumber;
                }
                else{
                    throw new Exception("Не корректный оператор" + operator);
                }
                operator = ch;
                currectNumber = 0;
            }
        }
        return result;
    }
}