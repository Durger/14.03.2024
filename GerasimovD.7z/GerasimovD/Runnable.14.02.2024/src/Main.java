import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*int v = (new Random().nextInt(10));
        MyThread3 r3 = new MyThread3(v);
        Thread t3 = new Thread(r3);
        t3.setDaemon(true);

        v = (new Random().nextInt(10));
        MyThread3 r31 = new MyThread3(v);
        Thread t31 = new Thread(r31);
        t31.setDaemon(true);
        t3.start();
        t31.start();

        //interrupt - "флаг" прерывание
        t31.isInterrupt();

        try {
            t3.join();
            t31.join();
        }
        catch (InterruptedException e) {
        }*/



       /* //Задача.1
        // Напишите программу, которая создает поток, выполняющий некоторую работу, и затем прерывает его
        // с помощью метода interrupt(). Поток должен проверять свое состояние на предмет прерывания и завершать свою работу,
        // если он был прерван. Задержка = 5000 мс

        Thread thread = new Thread(new MyThread5());
        thread.start();
        try{
          Thread.sleep(5000);
          thread.isInterrupt();
          thread.join();
        }
        catch (InterruptedException e){
         e.printStackTrace();
        }*/


      /*  //Задача.2.
// Напишите программу, которая создает несколько потоков и прерывает их с помощью метода interrupt().
// Каждый поток должен выполнять свою работу в течение некоторого времени, а затем проверять свое состояние на
// предмет прерывания и завершать работу, если он был прерван.
        Thread thread = new Thread(new MyThread54());
        Thread thread2 = new Thread(new MyThread54());
        thread.start();
        thread2.start();
        try{
            Thread.sleep(2000);
            thread.interrupt();
            Thread.sleep(2000);
            thread2.interrupt();
            thread.join();
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }*/


        //Задача.3.
        // Напишите программу, которая создает поток, выполняющий работу по подсчету суммы чисел от 1 до заданного
        // числа N. Пользователь должен ввести значение N с клавиатуры. В случае, если пользователь вводит
        // отрицательное число, программа должна прерывать поток с помощью метода interrupt().
        System.out.println("Wright number");
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();
        if (N < 0){
            System.out.println("Input negative number!!!!");
            thread.interrupt();
            return;
        }
        Thread thread = new Thread(new SumCalculator(N));
        thread.start();
        try {
            thread.join();
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
        System.out.println("Sum of numbers 1 to " + N + ":" + SumCalculator.getSum());

    }
}

//Класс для Задачи.1
//class  MyThread5 implements Runnable{
//    @Override
//    public void run() {
//        while (!Thread.currentThread().isInterrupted()){
//            System.out.println("I worked");
//            try {
//                Thread.sleep(1000);
//            }
//            catch (InterruptedException e){
//                System.out.println("Threads be Interrupted");
//            }
//        }
//    }
//}

//Класс для Задачи.2
class  MyThread54 implements Runnable{
    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()){
            System.out.println("I worked" + Thread.currentThread().getId() );
            try {
                Thread.sleep(1000);
            }
            catch (InterruptedException e){
                System.out.println("Threads be Interrupted"+Thread.currentThread().getId());
                return;
            }
        }
    }
}

//Класс для Задачи.3
class  SumCalculator implements Runnable{
    private  int N;
    private static int sum;
    public SumCalculator (int n){
        this.N = n;
    }
    public static int getSum() {
        return sum;
    }

    @Override
    public void run() {
        for (int i = 0; i <=0; i++){
            sum+= 1;
            if (Thread.currentThread().isInterrupted()){
                System.out.println("Thread is stop");
                return;
            }
        }
    }
}







class MyThread3 implements Runnable{
    private int value;
    public MyThread3(int v){
        this.value = v;
    }
    @Override
    public void run() {
        int limit = this.value/2;
        System.out.println("******* The thread " + Thread.currentThread().getName() + "start with " + this.value);
        while (this.value >= 0){
            System.out.println("From " + Thread.currentThread().getName() + "value  = " + this.value);
            this.value -=1;
            if(this.value >= limit && Thread.currentThread().isInterrupted()){
                System.out.println("******* The thread is interrupted ");
                return;
            }
            try {
                Thread.sleep(300);
            }
            catch (InterruptedException e){
                System.out.println("******* The thread " + Thread.currentThread().getName() + " has finished in catch");
            }
        }
        System.out.println("******* The thread " + Thread.currentThread().getName() + " has finished");
    }
}