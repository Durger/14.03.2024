import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class UserInfo implements Externalizable {
    private  String firstName;
    private  String lastName;
    private  String superSecretInformation;
    private static final long serialVersionUID = 1L;
    public UserInfo(String firstName, String lastName,String superSecretInformation){
        this.firstName = firstName;
        this.lastName = lastName;
        this.superSecretInformation =  superSecretInformation;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public String getSuperSecretInformation() {
        return superSecretInformation;
    }
    public UserInfo(){
    }
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject((this.getFirstName()));
        out.writeObject((this.getLastName()));
        out.writeObject((this.encryptString(getSuperSecretInformation())));
    }
    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        firstName = (String)in.readObject();
        lastName = (String)in.readObject();
        superSecretInformation = this.decryptString((String)in.readObject());
    }
    //метод кодирования
    private String encryptString (String data){
        String encryptData = Base64.getEncoder().encodeToString(data.getBytes());
        System.out.println(encryptData);
        return  encryptData;
    }
    //метод декодирования
    private String decryptString (String data){
        String decrypted = new String(Base64.getDecoder().decode(data));
        System.out.println(decrypted);
        return decrypted;
    }
}
